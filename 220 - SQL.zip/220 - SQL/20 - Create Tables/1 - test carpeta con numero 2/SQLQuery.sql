
INSERT INTO [dbo].[AppVersions]
           ([App_Name]
           ,[App_Version]
           ,[Modified_On])
     VALUES
           ('test app'
           ,'1.0'
           ,GETDATE())
GO

