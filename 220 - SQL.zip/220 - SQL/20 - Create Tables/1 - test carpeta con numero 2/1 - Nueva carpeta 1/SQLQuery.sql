
INSERT INTO [dbo].[AppVersions]
           ([App_Name]
           ,[App_Version]
           ,[Modified_On])
     VALUES
           ('test app ahora si'
           ,'1.2.1'
           ,GETDATE())
GO

